package com.inventory.service;

import java.util.List;

import com.inventory.dto.InventoryDto;
import com.inventory.exception.InventoryIdNotFoundException;
import com.inventory.exception.NoInventoryFoundException;
import com.inventory.model.Inventory;

public interface InventoryService {

	List<Inventory> getAllInventories() throws NoInventoryFoundException;

	Inventory getInventoryById(Long id) throws InventoryIdNotFoundException;

	Inventory createInventory(InventoryDto inventoryDto);

	Inventory updateInventory(Long id, InventoryDto inventoryDto) throws InventoryIdNotFoundException;

	Inventory deleteInventory(Long id) throws InventoryIdNotFoundException;

	 List<Inventory> getInventoriesByLocation(String location) throws NoInventoryFoundException;
	
}
