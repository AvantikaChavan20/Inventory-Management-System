package com.inventory.dto;

import lombok.Data;

@Data
public class InventoryDto {
	private String category;
	private String location;
}
