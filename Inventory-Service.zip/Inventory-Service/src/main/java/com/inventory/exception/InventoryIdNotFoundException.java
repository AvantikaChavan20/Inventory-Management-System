package com.inventory.exception;

public class InventoryIdNotFoundException extends Exception{
	public InventoryIdNotFoundException (String msg) {
		super(msg);
	}
}
