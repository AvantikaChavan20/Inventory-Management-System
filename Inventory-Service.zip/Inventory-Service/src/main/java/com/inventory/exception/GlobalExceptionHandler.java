package com.inventory.exception;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;
import org.springframework.web.context.request.WebRequest;

@RestControllerAdvice
public class GlobalExceptionHandler {
	
	@ExceptionHandler(InventoryIdNotFoundException.class)
    public ResponseEntity<ErrorDetails> handleInventoryIdNotFoundException(Exception ex, WebRequest request) {
        ErrorDetails errorDetails = new ErrorDetails(
        		request.getDescription(false).substring(4),
        		LocalDateTime.now().format(DateTimeFormatter.ISO_LOCAL_DATE_TIME),
        		ex.getClass().getSimpleName(),
        		ex.getMessage());
        return new ResponseEntity<>(errorDetails, HttpStatus.NOT_FOUND);
    }
	
	@ExceptionHandler(NoInventoryFoundException.class)
	public ResponseEntity<ErrorDetails> handleNoInventoryFoundException(Exception ex, WebRequest request) {
		ErrorDetails errorDetails = new ErrorDetails(
				request.getDescription(false).substring(4),
				LocalDateTime.now().format(DateTimeFormatter.ISO_LOCAL_DATE_TIME),
				ex.getClass().getSimpleName(),
				ex.getMessage());
		return new ResponseEntity<>(errorDetails, HttpStatus.NOT_FOUND);
	}
	
	@ExceptionHandler(DataIntegrityViolationException.class)
	public ResponseEntity<ErrorDetails> handleValidations(Exception ex, WebRequest request) {
		ErrorDetails errorDetails = new ErrorDetails(
				request.getDescription(false).substring(4),
				LocalDateTime.now().format(DateTimeFormatter.ISO_LOCAL_DATE_TIME),
				ex.getClass().getSimpleName(),
				ex.getMessage());
		return new ResponseEntity<>(errorDetails, HttpStatus.BAD_REQUEST);
	}
	
	@ExceptionHandler(Exception.class)
    public ResponseEntity<ErrorDetails> handleAllExceptions(Exception ex, WebRequest request) {
        String path = request.getDescription(false).substring(4);
        String timestamp = LocalDateTime.now().format(DateTimeFormatter.ISO_LOCAL_DATE_TIME);
        String error = ex.getClass().getSimpleName();
        String details = ex.getMessage();

        ErrorDetails errorDetails = new ErrorDetails(path, timestamp, error, details);

        return new ResponseEntity<>(errorDetails, HttpStatus.INTERNAL_SERVER_ERROR);
    }
	
	@ExceptionHandler(RuntimeException.class)
    public ResponseEntity<ErrorDetails> handleRuntimeException(Exception ex, WebRequest request) {
        ErrorDetails errorDetails = new ErrorDetails(
        		request.getDescription(false).substring(4),
        		LocalDateTime.now().format(DateTimeFormatter.ISO_LOCAL_DATE_TIME),
        		ex.getClass().getSimpleName(),
        		ex.getMessage());
        return new ResponseEntity<>(errorDetails, HttpStatus.BAD_REQUEST);
    }
}
